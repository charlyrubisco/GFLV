data('3ab22541-3a38-4cd3-980a-e857fc28d517\n\
')