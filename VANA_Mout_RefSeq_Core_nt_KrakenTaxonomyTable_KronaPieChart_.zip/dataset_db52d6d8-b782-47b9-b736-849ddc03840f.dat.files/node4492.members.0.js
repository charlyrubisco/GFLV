data('a6e92a88-a510-4f6d-adae-8ce5ff0fdfc8\n\
')