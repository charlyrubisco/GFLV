data('ff7c88fd-5310-49c2-bb5b-a64258df3aa8\n\
fc78d559-ac56-4294-b00f-06fba637dc93\n\
')