data('17ec9ced-2396-4b5f-8021-7f7a38ef1f80\n\
')