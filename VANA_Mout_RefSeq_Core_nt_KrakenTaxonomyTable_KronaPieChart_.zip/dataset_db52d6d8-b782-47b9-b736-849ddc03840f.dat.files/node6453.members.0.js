data('fba00992-ef10-45a8-9bad-c7a23ea43b0a\n\
')