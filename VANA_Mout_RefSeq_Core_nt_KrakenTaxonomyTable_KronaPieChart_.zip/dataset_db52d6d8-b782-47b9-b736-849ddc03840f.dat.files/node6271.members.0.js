data('57cee0f4-1a89-40fe-a00a-82e2a1d6bc1d\n\
')