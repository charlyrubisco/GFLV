data('698c6180-7a7d-4147-a5ab-f0f79054f8a5\n\
')