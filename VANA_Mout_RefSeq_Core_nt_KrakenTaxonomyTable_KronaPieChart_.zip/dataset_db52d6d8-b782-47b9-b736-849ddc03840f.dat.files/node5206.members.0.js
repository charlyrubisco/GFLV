data('2b2c8e47-89d7-4b6c-b8b8-abf6a5e2b5ad\n\
6b69589f-a4d4-4f93-8c5c-e5aa1e131245\n\
cbb5dd2c-0022-4bf8-bdd8-b1de8cfe2d26\n\
f31a75de-ce61-447b-ae7a-395a11f67f2a\n\
')