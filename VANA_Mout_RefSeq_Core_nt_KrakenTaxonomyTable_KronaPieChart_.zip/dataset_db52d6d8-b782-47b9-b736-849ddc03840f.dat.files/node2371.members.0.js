data('00b6d23c-8a4c-47da-bbe3-03dc276c0c65\n\
9d3e6dda-0521-4f48-a581-6e24090ca45d\n\
77e1451c-3f6a-4cfa-b84e-97fd68ad134c\n\
ed839a86-2101-41f0-abcf-e63ed582fd35\n\
7cba9c02-9f5b-4c27-aae5-dc74866fbe38\n\
')