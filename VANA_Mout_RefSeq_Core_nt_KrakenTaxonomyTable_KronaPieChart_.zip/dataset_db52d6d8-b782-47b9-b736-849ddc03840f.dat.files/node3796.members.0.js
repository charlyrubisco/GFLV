data('dc6c47ba-08be-4311-9b0a-2e93241dceaf\n\
')