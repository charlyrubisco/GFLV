data('43ff3170-0c67-4668-9aaf-6d52ed015f94\n\
')