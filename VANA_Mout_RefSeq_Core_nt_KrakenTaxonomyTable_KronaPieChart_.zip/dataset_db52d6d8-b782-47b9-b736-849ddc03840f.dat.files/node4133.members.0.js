data('7ffa9ea0-47fe-48b6-be1d-1919b9cf11fe\n\
a5616ee5-0926-408d-bfbc-126f637bbee9\n\
a5c852ba-2ab7-4e4f-a574-ba089162d2b6\n\
a66e015e-34da-495c-a9a7-1615e90a8382\n\
a1ad2ce1-93b6-4b48-91e0-2a05de835ece\n\
')