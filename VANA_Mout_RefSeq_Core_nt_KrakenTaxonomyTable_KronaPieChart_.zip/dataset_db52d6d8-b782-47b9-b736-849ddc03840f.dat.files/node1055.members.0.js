data('d5a6e31a-8c9f-4048-ac4b-f67e7fc6a6b9\n\
')