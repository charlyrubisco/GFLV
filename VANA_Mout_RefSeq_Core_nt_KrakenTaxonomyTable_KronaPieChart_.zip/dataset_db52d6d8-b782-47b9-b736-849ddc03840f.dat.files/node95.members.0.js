data('6b8ad7fa-6e2f-4657-85ac-dcfc7fae89da\n\
3bc7d001-cbd9-4c5a-b2f2-7d395ef16fe9\n\
69bbd8e5-eec7-496e-b73d-3a2d630e51c5\n\
')