data('10e04dec-fc6d-4a88-a56d-08b2842816a0\n\
')