data('0f672d79-415a-4ec4-a139-3313b1c1d19e\n\
')