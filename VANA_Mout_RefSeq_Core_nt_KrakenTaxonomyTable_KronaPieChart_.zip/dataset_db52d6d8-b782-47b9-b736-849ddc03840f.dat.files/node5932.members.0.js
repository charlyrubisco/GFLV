data('25bdeaf6-b1a2-4ee8-a0f0-dac0ecfb61fe\n\
cbaa0d71-5ea1-46f2-ac0f-cdfd22a7d477\n\
8173a18e-254a-4b5c-b1d4-55d0383cbbc5\n\
d8427c62-b41b-497d-8187-4b4f62471107\n\
')