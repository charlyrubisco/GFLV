data('e6f69ab4-0fd3-497f-89e1-0a55c9d6c6bc\n\
')