data('04a7a9dc-b444-42ab-9ced-9eda450a32b3\n\
')