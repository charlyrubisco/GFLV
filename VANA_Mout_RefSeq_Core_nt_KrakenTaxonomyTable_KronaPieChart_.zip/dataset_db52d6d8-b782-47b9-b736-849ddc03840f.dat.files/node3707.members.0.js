data('df86a596-3648-442f-9cd4-9b1e2ad9ed32\n\
529b81eb-cee8-43c6-ba8e-dfd3fadbba63\n\
e5d06815-a80a-4ff8-b11b-b5dbd05cacd0\n\
')